import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Configuración básica para un proyecto con React y Vite
export default defineConfig({
  plugins: [react()],
});