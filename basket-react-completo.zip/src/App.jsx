import React from 'react';
import RosterTable from './components/RosterTable';

const App = () => {
  return (
    <div>
      <RosterTable />
    </div>
  );
};

export default App;