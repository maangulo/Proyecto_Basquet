export const players = [
  { number: 3, name: 'Kevin Harrell', team: 'Top Club', position: 'Guard' },
  { number: 5, name: 'James Fletcher', team: 'Top Club', position: 'Center' },
  { number: 14, name: 'Jeff Montes', team: 'Top Club', position: 'Forward-Guard' },
  { number: 27, name: 'Bryan Warner', team: 'Top Club', position: 'Forward-Center' },
  { number: 30, name: 'Scott Dale', team: 'Top Club', position: 'Forward' },
  { number: 37, name: 'Noah Jones', team: 'Top Club', position: 'Guard' },
];